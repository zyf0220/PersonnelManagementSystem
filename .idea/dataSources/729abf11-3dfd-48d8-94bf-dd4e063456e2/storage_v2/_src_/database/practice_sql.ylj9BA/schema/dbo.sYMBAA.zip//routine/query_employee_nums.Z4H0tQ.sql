-- 创建存储过程
create procedure query_employee_nums
as
begin
    select dept, title, count(title) 'num' from query_employee_info group by dept, title;
end
go

