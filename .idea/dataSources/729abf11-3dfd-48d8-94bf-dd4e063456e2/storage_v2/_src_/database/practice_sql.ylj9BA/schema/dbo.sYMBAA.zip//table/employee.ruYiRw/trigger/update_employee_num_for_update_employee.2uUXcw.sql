create trigger update_employee_num_for_update_employee
    on employee
    for update
    as
begin
    if (select dept_id from deleted) <> (select dept_id from inserted)
        update department set employee_num = employee_num + 1 where id = (select dept_id from inserted)
        update department set employee_num = employee_num - 1 where id = (select dept_id from deleted)
    if (select position_id from deleted) <> (select position_id from inserted)
        update position set employee_num = employee_num + 1 where id = (select position_id from inserted)
        update position set employee_num = employee_num - 1 where id = (select position_id from inserted)
    if (select title_id from deleted) <> (select title_id from inserted)
        update title set employee_num = employee_num + 1 where id = (select title_id from inserted)
        update title set employee_num = employee_num - 1 where id = (select title_id from inserted)
end
go

