-- 创建存储过程
-- 因为上面创建的query_employee_info视图已经包含了聚合了所有需要的信息，所以这里直接从该视图取数据进行处理即可
-- 创建存储过程查询各个部门,各种职称的职工数量
create procedure query_employee_nums_in_diff_dept_with_diff_title
as
begin
    select dept, title, count(title) 'num' from query_employee_info group by dept, title;
end
go

