-- 创建存储过程，视图，触发器
-- 创建视图
create view query_employee_info
as
select e.employee_id, e.name "employee_name", d.name 'dept', p.name 'title', t.name 'position'
from employee e
         left join department d on e.dept_id = d.id
         left join position p on e.position_id = p.id
         left join title t on e.title_id = t.id
go

