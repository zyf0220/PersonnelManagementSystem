-- 创建触发器
-- 新增员工后自动更新员工数量
create trigger update_employee_num_for_insert_employee
    on employee
    for insert
    as
begin
    update department set employee_num = employee_num + 1 where id = (select dept_id from inserted)
    update position set employee_num = employee_num + 1 where id = (select position_id from inserted)
    update title set employee_num = employee_num + 1 where id = (select title_id from inserted)
end
go

